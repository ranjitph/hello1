<?php

return [

	/*
	* Edit this file in order to configure your application's
	* constants. 
	*
	* The key is the constant NAME (be sure to write it capitals)
	* and key's value is the constant VALUE.
	*/
	'THEME_VERSION'	=> '1.3.0'

];