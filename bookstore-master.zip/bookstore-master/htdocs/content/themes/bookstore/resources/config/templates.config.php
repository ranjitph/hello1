<?php

return [

	/*
	 * Edit this file in order to configure your page
	 * templates.
	 *
	 * Simply define a template slug.
	 */
	'about' => __("About", THEME_TEXTDOMAIN)
];