<?php

use Themosis\Facades\Route;

/**
 * Plugin custom routes.
 */